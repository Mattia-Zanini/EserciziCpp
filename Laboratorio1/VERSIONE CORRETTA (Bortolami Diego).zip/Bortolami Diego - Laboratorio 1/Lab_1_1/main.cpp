//Lab_1: Esercizio 1 - Revisione finale
#include <iostream>

int main()
{
	std::cout << "Hello, World\n";
	
	return 0;
}